﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Gvinci.Plugin.Action
{
    public class GPluginActionAKBR11301 : GPluginAction
    {
        public override string ID => "6CACD40E-4F99-4D96-0001-C827AF67A9C2";

        public override string Name => "R11301";

        public override string Description => "";

        private List<GPluginActionParameter> _Parameters;
        public override List<GPluginActionParameter> Parameters
        {
            get
            {
                return _Parameters;
            }
        }

        public GPluginActionAKBR11301(IGPlugin Plugin) : base(Plugin)
        {
            _Parameters = new List<GPluginActionParameter>()
                    {
                        new GPluginActionParameter() { ID = 1, Name = "UnidadeMedida", Type = PluginActionParameterTypeEnum.DECIMAL },
                        new GPluginActionParameter() { ID = 2, Name = "SiglaProd", Type = PluginActionParameterTypeEnum.STRING },
                    };
        }
        public override void WriteActionCall(StringBuilder Builder, int Identation, int ActionSequence)
        {
            string unidade = this.Parameters[0].Value.ToString();
            string sigla = this.Parameters[1].Value.ToString();

            string idenStr = new string('\t', Identation);

            Builder.AppendLine(idenStr + "string connString = \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=191.13.138.110)(PORT=2226))(CONNECT_DATA=(SERVICE_NAME=dassistest)))\";");
            Builder.AppendLine(idenStr + "System.Data.OracleClient.OracleConnection conn = new System.Data.OracleClient.OracleConnection(\"Data Source=\" + connString + \";User ID=akbit;Password=Fama1200\");");
            Builder.AppendLine(idenStr + "conn.Open();");
            Builder.AppendLine(idenStr + "System.Data.OracleClient.OracleTransaction trans = conn.BeginTransaction();");
            Builder.AppendLine(idenStr + "clsRuleDynamicallyCompiled_R11301.R11301(ref conn, ref trans, " + unidade + ", " + sigla + ");");
            Builder.AppendLine(idenStr + "trans.Commit();");
            Builder.AppendLine(idenStr + "conn.Close();");

        }

        public override List<GPluginDependency> GetDependenciesFiles()
        {
            return new List<GPluginDependency>()
            {
                new GPluginDependency() { FileName = "R11301.vb", DestinationRelativePath = "App_Code/vb", AllowReplace = true }
            };
        }

    }
}