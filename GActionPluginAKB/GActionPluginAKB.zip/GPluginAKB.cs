﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gvinci.Plugin.Action
{
    public class GPluginAKB : IGPlugin
    {
        public string ID => "6CACD40E-4F99-4D96-0000-C827AF67A9C2";
        public string Name => "AKB Integration";
        public string Description => "Integration with AKB Function";
        public string CompatibilityVersion => "2022";
        public string ProjectType => "CSHARP";

        public List<GPluginAction> Actions
        {
            get
            {
                return new List<GPluginAction>()
                {
                    new GPluginActionAKBR11301(this),
                };
            }
        }

        public List<GPluginDependency> GetDependenciesFiles()
        {
            return new List<GPluginDependency>();
        }

    }
}